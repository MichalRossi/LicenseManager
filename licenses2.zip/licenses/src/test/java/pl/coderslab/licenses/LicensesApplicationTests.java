package pl.coderslab.licenses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicensesApplicationTests {

    @Test
    void contextLoads() {
    }

}
