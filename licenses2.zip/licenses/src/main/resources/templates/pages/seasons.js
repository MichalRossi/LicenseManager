$(document).ready(function() {
    getSeasons();

});


function getSeasons() {

   var list = $('<ol>');
    $.ajax({
        url: SEASONS_URL,
        method: 'GET',
        data: JSON
    }).done(function(result){
        result.forEach(function(element) {

            var listElement = $('<li>');
            listElement.text(element.startYear + '/' + element.endYear);

        }
        );
        list.append(listElement);
    });
}

