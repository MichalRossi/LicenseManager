$(document).ready(function() {
    clearAndGetCoaches();
    registerAddButton();
    //registerSaveButton();
});


var CLUBS_URL = 'http://localhost:8080/clubs';
var PLAYERS_URL = 'http://localhost:8080/clubs';
var COACHES_URL = 'http://localhost:8080/coaches';
var SEASONS_URL = 'http://localhost:8080/seasons';

function clearAndGetCoaches() {

    var table = $('.table');
    var tabBody = $('.tabBody');
    tabBody.empty();
    $.ajax({
        url: COACHES_URL,
        method: 'GET',
        data: JSON
    }).done(function(result){
        result.forEach(function(element) {
            console.log(element)

            var row = $('<tr>');

            var colId = $('<th>');
            colId.text(element.id);
            row.append(colId);

            var colFirstName = $('<td>');
            colFirstName.text(element.firstName);
            row.append(colFirstName);

            var colSecondName = $('<td>');
            colSecondName.text(element.lastName);
            row.append(colSecondName);

            var colGender = $('<td>');
            colGender.text(element.gender);
            row.append(colGender);

            var colAgeCategory = $('<td>');
            colAgeCategory.text(element.ageCategory);
            row.append(colAgeCategory);

            var colValid = $('<td>');
            colValid.text(element.valid);
            row.append(colValid);

            var colClub = $('<td>');
            colClub.text(element.club.name);
            row.append(colClub);

            var colBtn = $('<td>');
            colBtn.append(createDeleteButton(element));
            colBtn.append(createEditButton(element));
            row.append(colBtn);

            tabBody.append(row);

        }
        );
        table.append(tabBody);
    });
}

function createEditButton(element) {
    var editButton = $('<span>');
    editButton.text('Edit');
    editButton.addClass('btn');
    editButton.addClass('btn-info');
    editButton.addClass('btn-sm');
    editButton.addClass('float-right');
    editButton.on('click', function() {
        registerFillingValuesAfterCardClick(element);
        $('#addCoachesForm').css("display", "");
        window.scrollTo(0, 0);
    });
    return editButton;
}

function createDeleteButton(element) {
    var deleteButton = $('<span>');
    deleteButton.text('Delete');
    deleteButton.addClass('btn');
    deleteButton.addClass('btn-danger');
    deleteButton.addClass('btn-sm');
    deleteButton.addClass('float-right');
    deleteButton.on('click', function() {
        $.ajax({
            url: COACHES_URL + "/" + element.id,
            contentType: "application/json",
            method: "DELETE"
        }).done(function () {
            clearAndGetCoaches();
        });
    });
    return deleteButton;
}

function registerAddButton() {
    $('#addCoachBtn').on('click', function() {
        var addForm = $('#addCoachForm');
        //clearInputFields();
        if(addForm.css("display") === "none"){
            addForm.css("display", "");
        }
        else{
            addForm.css("display", "none");
        }
    });
}

function registerSaveButton() {
    $('#saveBtn').on('click', function(e) {
        e.preventDefault();

        // var colFirstName = $('<td>');
        // colFirstName.text(element.firstName);
        // row.append(colFirstName);
        //
        // var colSecondName = $('<td>');
        // colSecondName.text(element.lastName);
        // row.append(colSecondName);
        //
        // var colGender = $('<td>');
        // colGender.text(element.gender);
        // row.append(colGender);
        //
        // var colAgeCategory = $('<td>');
        // colAgeCategory.text(element.ageCategory);
        // row.append(colAgeCategory);
        //
        // var colValid = $('<td>');
        // colValid.text(element.valid);
        // row.append(colValid);
        //
        // var colClub = $('<td>');
        // colClub.text(element.club);
        // row.append(colClub);




        var coach = {
            firstName: $('#firstName').val(),
            lastName: $('#lastName').val(),
            gender: $('#gender').val(),
            ageCategory: $('#ageCategory').val(),
            valid: $('#valid').val(),
            club : {
                city:$('#city').val(),
                zipCode:$('#zipCode').val(),
                streetName:$('#street').val(),
                streetNumber:$('#streetNumber').val(),

            }
        };
        console.log(club);

        var clubId = $('#clubId').val();
        console.log(clubId);


        if(clubId) {
            $.ajax({
                url: CLUBS_URL + "/" + clubId,
                data: JSON.stringify(club),
                contentType: "application/json",
                method: "PUT"
            }).done(function () {
                clearAndGetClubs();
                clearInputFields();
            });
        } else {
            $.ajax({
                url: CLUBS_URL + "/",
                data: JSON.stringify(club),
                contentType: "application/json",
                method: "POST"
            }).done(function () {
                clearAndGetClubs();
                clearInputFields();
            });
        }

    });
}

function clearInputFields() {
    $('#name').val('');
    $('#email').val('');
    $('#nip').val('');
    $('#phoneNumber').val('');
    $('#webAddress').val('');
    $('#city').val('');
    $('#zipCode').val('');
    $('#street').val('');
    $('#streetNumber').val('');
    $('#clubId').val('');

}