$(document).ready(function() {
    clearAndGetPlayers();

});



var CLUBS_URL = 'http://localhost:8080/clubs';
var PLAYERS_URL = 'http://localhost:8080/clubs';
var COACHES_URL = 'http://localhost:8080/clubs';

function clearAndGetPlayers() {

    var table = $('.table');
    var tabBody = $('.tabBody');
    tabBody.empty();
    $.ajax({
        url: PLAYERS_URL,
        method: 'GET',
        data: JSON
    }).done(function(result){
        result.forEach(function(element) {

            var row = $('<tr>');

            // <th scope="col">License no</th>
            //     <th scope="col">First name</th>
            //     <th scope="col">Second name</th>
            //     <th scope="col">Gender</th>
            //     <th scope="col">Age category</th>
            //     <th scope="col">Medical exam</th>
            //     <th scope="col">Valid</th>
            //     <th scope="col">Club</th>


            var colId = $('<th>');
            colId.text(element.id);
            row.append(colId);

            var colFirstName = $('<td>');
            colFirstName.text(element.firstName);
            row.append(colFirstName);

            var colSecondName = $('<td>');
            colSecondName.text(element.lastName);
            row.append(colSecondName);

            var colGender = $('<td>');
            colGender.text(element.gender);
            row.append(colGender);

            var colAgeCategory = $('<td>');
            colAgeCategory.text(element.ageCategory);
            row.append(colAgeCategory);

            var colMedicalExam = $('<td>');
            colMedicalExam.text(element.medicalExam);
            row.append(colMedicalExam);

            var colValid = $('<td>');
            colValid.text(element.valid);
            row.append(colValid);

            var colClub = $('<td>');
            colClub.text(element.club);
            row.append(colClub);

        }
        );
        table.append(tabBody);
    });
}

