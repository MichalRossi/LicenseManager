$(document).ready(function() {

    clearAndGetClubs();
    registerAddButton();
    registerSaveButton();

});



var CLUBS_URL = 'http://localhost:8080/clubs';
var PLAYERS_URL = 'http://localhost:8080/players';
var COACHES_URL = 'http://localhost:8080/coaches';

function clearAndGetClubs() {

    var table = $('.table');
    var tabBody = $('.tabBody');
    tabBody.empty();
    $.ajax({
        url: CLUBS_URL,
        method: 'GET',
        data: JSON
    }).done(function(result){
        result.forEach(function(element) {

            var row = $('<tr>');

            var colId = $('<th>');
            colId.text(element.id);
            row.append(colId);

            var colAgeCategories = $('<td>');
            colAgeCategories.text(element.ageCategory);
            row.append(colAgeCategories);


            var colName = $('<td>');
            colName.text(element.name);
            row.append(colName);


            var colNip = $('<td>');
            colNip.text(element.nip);
            row.append(colNip);


            var colAddress = $('<td>');
            colAddress.text('ul. ' + element.address.streetName + ' ' + element.address.streetNumber + ', ' + element.address.zipCode + ' ' + element.address.city );
            row.append(colAddress);


            var colWebAddress = $('<td>');
            colWebAddress.text(element.webAddress);
            row.append(colWebAddress);


            var colEmail = $('<td>');
            colEmail.text(element.email);
            row.append(colEmail);

            var colPlayers = $('<td>');
            var playersListButton = createPlayersListButton(element.id);
            colPlayers.append(playersListButton);
            row.append(colPlayers);

            var colCoaches = $('<td>');
            var coachesListButton = createCoachesListButton(element.id);
            colCoaches.append(coachesListButton);
            row.append(colCoaches);

            var colBtn = $('<td>');
            colBtn.append(createDeleteButton(element));
            colBtn.append(createEditButton(element));
            row.append(colBtn);

            tabBody.append(row);

        }
        );
        table.append(tabBody);

        var addForm = $('#addClubForm');
        addForm.css("display", "none");

}
    )}

function createPlayersListButton(id) {
    var playersListButton = $('<button>');
    playersListButton.text('Players');
    playersListButton.addClass('btn');
    playersListButton.addClass('btn-primary');
    playersListButton.addClass('btn-sm');
    playersListButton.addClass('float-middle');
    playersListButton.on('click', function() {
            location.href = "players.html";
    });
    return playersListButton;
}

function createCoachesListButton(id) {
    var coachesListButton = $('<button>');
    coachesListButton.text('Coaches');
    coachesListButton.addClass('btn');
    coachesListButton.addClass('btn-primary');
    coachesListButton.addClass('btn-sm');
    coachesListButton.addClass('float-middle');
    coachesListButton.on('click', function() {
        location.href = "coaches.html";
    });

    return coachesListButton;
}

function registerFillingValuesAfterCardClick(element) {
    $('#name').val(element.name);
    $('#email').val(element.email);
    $('#nip').val(element.nip);
    $('#phoneNumber').val(element.phoneNumber);
    $('#webAddress').val(element.webAddress);
    $('#city').val(element.address.city);
    $('#zipCode').val(element.address.zipCode);
    $('#street').val(element.address.streetName);
    $('#streetNumber').val(element.address.streetNumber);
    $('#clubId').val(element.id);
}

function createEditButton(element) {
    var editButton = $('<span>');
    editButton.text('Edit');
    editButton.addClass('btn');
    editButton.addClass('btn-info');
    editButton.addClass('btn-sm');
    editButton.addClass('float-right');
    editButton.on('click', function() {
        registerFillingValuesAfterCardClick(element);
        $('#addClubForm').css("display", "");
        window.scrollTo(0, 0);
    });
    return editButton;
}

function createDeleteButton(element) {
    var deleteButton = $('<span>');
    deleteButton.text('Delete');
    deleteButton.addClass('btn');
    deleteButton.addClass('btn-danger');
    deleteButton.addClass('btn-sm');
    deleteButton.addClass('float-right');
    deleteButton.on('click', function() {
        $.ajax({
            url: CLUBS_URL + "/" + element.id,
            contentType: "application/json",
            method: "DELETE"
        }).done(function () {
            clearAndGetClubs();
        });
    });
    return deleteButton;
}


function registerAddButton() {
    $('#addClubBtn').on('click', function() {
        var addForm = $('#addClubForm');
        clearInputFields();
        if(addForm.css("display") === "none"){
            addForm.css("display", "");
        }
        else{
            addForm.css("display", "none");
        }
    });
}

function registerSaveButton() {
    $('#saveBtn').on('click', function(e) {
        e.preventDefault();
        var club = {
            name: $('#name').val(),
            email: $('#email').val(),
            nip: $('#nip').val(),
            phoneNumber: $('#phoneNumber').val(),
            webAddress: $('#webAddress').val(),
            address : {
                city:$('#city').val(),
                zipCode:$('#zipCode').val(),
                streetName:$('#street').val(),
                streetNumber:$('#streetNumber').val(),

            }
        };
        console.log(club);

        var clubId = $('#clubId').val();
        console.log(clubId);


        if(clubId) {
            $.ajax({
                url: CLUBS_URL + "/" + clubId,
                data: JSON.stringify(club),
                contentType: "application/json",
                method: "PUT"
            }).done(function () {
                clearAndGetClubs();
                clearInputFields();
            });
        } else {
            $.ajax({
                url: CLUBS_URL + "/",
                data: JSON.stringify(club),
                contentType: "application/json",
                method: "POST"
            }).done(function () {
                clearAndGetClubs();
                clearInputFields();
            });
        }

    });
}

function clearInputFields() {
    $('#name').val('');
    $('#email').val('');
    $('#nip').val('');
    $('#phoneNumber').val('');
    $('#webAddress').val('');
    $('#city').val('');
    $('#zipCode').val('');
    $('#street').val('');
    $('#streetNumber').val('');
    $('#clubId').val('');

}