$(function(){
    $('#navigationBar').load("navbar.html");
});