package pl.coderslab.club;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import pl.coderslab.commons.AgeCategory;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@RequestMapping("/clubs")
public class ClubController {

    private final ClubRepository clubRepository;
    public ClubController(ClubRepository clubRepository) {
        this.clubRepository = clubRepository;
    }


    @GetMapping("/")
    public String clubsList(Model model) {
        model.addAttribute("clubs", clubRepository.findAll());
        return "club/clubsList";
    }


    @GetMapping("/add")
    public String addClub(Model model) {
        if (LocalDate.now().getMonthValue()!=8) {
            model.addAttribute("errorMessage", "Changes can be made only during transfer window.");
            return "club/addClub";
        }

        model.addAttribute("club", new Club());
        return "club/addClub";
    }


    @PostMapping("/add")
    public String addClub(Model model, @ModelAttribute @Valid Club club, BindingResult bindingResult) {
        if (bindingResult.hasErrors() ) {
            return "club/addClub";
        }

        else if (LocalDate.now().getMonthValue()!=8) {
            model.addAttribute("errorMessage", "Changes can be made only during transfer window.");
            return "club/addClub";
        }

        clubRepository.save(club);
        return "redirect:../clubs/";
    }


    @GetMapping("/update/{id}")
    public String update(@PathVariable Long id, Model model) {
        Optional<Club> club = clubRepository.findById(id);
        model.addAttribute("club", club);
        model.addAttribute("club", club);
        return "club/addClub";
    }


    @PostMapping("/update/{id}")
    public String update(@PathVariable Long id, Model model, @ModelAttribute @Valid Club club, BindingResult bindingResult) {
        if (bindingResult.hasErrors() ) {
            return "club/addClub";
        }

        else if (LocalDate.now().getMonthValue()!=8) {
            model.addAttribute("errorMessage", "Changes can be made only during transfer window.");
            return "club/addClub";
        }

        clubRepository.save(club);
        return "redirect:../";
    }


    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, Model model) {
        if (LocalDate.now().getMonthValue()!=8) {
            model.addAttribute("errorMessage", "Changes can be made only during transfer window.");
            return "club/addClub";
        }

        clubRepository.deleteById(id);
        return "redirect:../";
    }


    @ModelAttribute("ageCategories")
    public List<AgeCategory> ageCategories() {
        return Stream.of(AgeCategory.values())
                .collect(Collectors.toList());
    }


}
