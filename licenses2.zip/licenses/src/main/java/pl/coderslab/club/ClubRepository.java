package pl.coderslab.club;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ClubRepository extends JpaRepository<Club, Long> {

    @Query("select c from Club c where c.id = :id")
    Club findClubById(@Param("id") Long id);

    @Query(value = "select * from clubs  " +
            "join coaches_clubs on clubs.id = coaches_clubs.clubs_id " +
            "join coaches on coaches.id = coaches_clubs.coaches_id " +
            "where coaches.id = ?1" +
            "desc limit 1"
            , nativeQuery = true)

    Club findCoachLastClub(Long coachId);

}
