package pl.coderslab.player;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import pl.coderslab.clubHistory.ClubHistory;
import pl.coderslab.commons.AgeCategory;
import pl.coderslab.commons.Gender;
import pl.coderslab.club.Club;
import pl.coderslab.club.ClubRepository;
import pl.coderslab.season.Season;
import pl.coderslab.season.SeasonRepository;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Controller
@RequestMapping("/players")
public class PlayerController {

    private final PlayerRepository playerRepository;
    private final ClubRepository clubRepository;
    private final SeasonRepository seasonRepository;


    public PlayerController(PlayerRepository playerRepository, ClubRepository clubRepository, SeasonRepository seasonRepository) {
        this.playerRepository = playerRepository;
        this.clubRepository = clubRepository;
        this.seasonRepository = seasonRepository;
    }


    @GetMapping("/")
    public String playerList(Model model) {
        model.addAttribute("players", playerRepository.findAll());
        return "player/playersList";
    }


    @GetMapping("/add")
    public String addPlayer(Model model) {
        model.addAttribute("player", new Player());
        return "player/addPlayer";
    }


    @PostMapping("/add")
    public String addPlayer(Model model, @ModelAttribute @Valid Player player, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "player/addPlayer";
        }

        if (LocalDate.now().getMonthValue()!=8) {
            model.addAttribute("errorMessage", "Changes can be made only during transfer window.");
            return "club/addClub";
        }

        if(!player.isValid()){
            player.setValid(true);
        }

        ClubHistory playerHistory = new ClubHistory();
        Season currentSeason = seasonRepository.findLast();

        List<Season> firstStartSeason = new ArrayList<>();
        List<Season> firstEndSeason = new ArrayList<>();
        firstStartSeason.add(currentSeason);
        firstEndSeason.add(null);
        playerHistory.setStartSeasons(firstStartSeason);
        playerHistory.setEndSeason(firstEndSeason);

        List<Club> firstClub = new ArrayList<>();
        firstClub.add(player.getClub());
        playerHistory.setClubs(firstClub);

        player.setClubHistory(playerHistory);
        player.setAgeCategory();
        playerRepository.save(player);
        return "redirect:../players/";
    }


    @GetMapping("/update/{id}")
    public String update(@PathVariable Long id, Model model) {
        Optional<Player> player = playerRepository.findById(id);
        model.addAttribute("player", player);
        return "player/addPlayer";
    }


    @PostMapping("/update/{id}")
    public String update(@PathVariable Long id, Model model, @ModelAttribute @Valid Player player, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "player/addPlayer";
        }

        if (LocalDate.now().getMonthValue()!=8) {
            model.addAttribute("errorMessage", "Changes can be made only during transfer window.");
            return "club/addClub";
        }

        Player oldPlayer = playerRepository.findPlayerById(id);

        if(!oldPlayer.getClub().equals(player.getClub()) && player.isValid()){
            ClubHistory playerHistory = player.getClubHistory();
            Season currentSeason = seasonRepository.findLast();
            Club oldClub = oldPlayer.getClub();

            List<Season> playerStartSeasons = playerHistory.getStartSeasons();
            List<Season> playerEndSeasons = playerHistory.getEndSeason();
            playerStartSeasons.add(currentSeason);
            playerEndSeasons.set(0,currentSeason);
            playerEndSeasons.add(null);
            playerHistory.setStartSeasons(playerStartSeasons);
            playerHistory.setEndSeason(playerEndSeasons);

            List<Club> playerClubHistory = playerHistory.getClubs();
            playerClubHistory.add(oldClub);
            playerHistory.setClubs(playerClubHistory);

            player.setClubHistory(playerHistory);
        }

        if(!player.isValid()){
            ClubHistory playerHistory = player.getClubHistory();
            Season currentSeason = seasonRepository.findLast();

            List<Season> playerEndSeasons = playerHistory.getEndSeason();
            playerEndSeasons.set(0, currentSeason);
            playerHistory.setEndSeason(playerEndSeasons);

            player.setClubHistory(playerHistory);
        }

        playerRepository.save(player);
        return "redirect:../";
    }


    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        playerRepository.deleteById(id);
        return "redirect:../";
    }


    @ModelAttribute("ageCategories")
    public List<AgeCategory> ageCategories() {
        return Stream.of(AgeCategory.values())
                .collect(Collectors.toList());
    }

    @ModelAttribute("genders")
    public List<Gender> genders() {
        return Stream.of(Gender.values())
                .collect(Collectors.toList());
    }


    @ModelAttribute("clubs")
    public List<Club> clubs() {
        return clubRepository.findAll();
    }


    @GetMapping("/club/{id}")
    public String clubPlayers(@PathVariable Long id, Model model) {

        List<Player> clubPlayers = playerRepository.findPlayerByClub(id);

        model.addAttribute("players",clubPlayers);
        return "player/playersList";
    }

    @GetMapping("/season/{id}")
    public String seasonPlayers(@PathVariable Long id, Model model) {

        List<Player> players = playerRepository.findAll();
        Season season = seasonRepository.findById(id).orElse(null);

        List<Player> seasonPlayers = players.stream()
                .filter(p -> p.getClubHistory()
                        .getStartSeasons()
                        .stream()
                        .allMatch(s -> s.getStartYear() <= season.getStartYear()))
                .filter(p -> p.getClubHistory()
                        .getEndSeason().stream()
                        .allMatch(s -> s==null || s.getStartYear() >= season.getStartYear()))
                .collect(Collectors.toList());

        model.addAttribute("players",seasonPlayers);
        return "player/playersList";
    }

}
