package pl.coderslab.clubHistory;

import lombok.Data;

import pl.coderslab.club.Club;
import pl.coderslab.coach.Coach;
import pl.coderslab.player.Player;
import pl.coderslab.season.Season;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "clubHistory")
public class ClubHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @OneToMany(mappedBy = "clubHistory")
//    private List<Player> players = new ArrayList<>();
//
//    @OneToMany(mappedBy = "clubHistory")
//    private List<Coach> coaches = new ArrayList<>();

    @ManyToMany
    private List<Club> clubs= new ArrayList<>();

    @ManyToMany
    private List<Season> startSeasons= new ArrayList<>();

    @ManyToMany
    private List<Season> endSeason= new ArrayList<>();

    public ClubHistory() {
    }
}
