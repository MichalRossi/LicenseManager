package pl.coderslab.clubHistory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import pl.coderslab.coach.Coach;

public interface ClubHistoryRepository extends JpaRepository<ClubHistory, Long> {
    @Query("select c from ClubHistory ch where ch.coaches.id = :id")
    ClubHistory findByCoachId(@Param("id") Long id);

}
