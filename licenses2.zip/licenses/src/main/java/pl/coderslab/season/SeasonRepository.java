package pl.coderslab.season;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SeasonRepository extends JpaRepository<Season, Long> {

    @Query(value = "select * from seasons s order by s.start_year desc limit 1", nativeQuery = true)
    Season findLast();

    @Query(value = "select s.* from seasons s " +
            "join seasons_coaches sc on s.id = sc.seasons_id" +
            "join coaches c on c.id = sc.coaches_id" +
            "where c.id = ?1" +
            "order by s.start_year desc limit 1", nativeQuery = true)
    Season findCoachLastSeasons(Long coachId);

}
