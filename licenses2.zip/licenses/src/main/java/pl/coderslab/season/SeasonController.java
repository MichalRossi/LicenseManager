package pl.coderslab.season;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;


@Controller
@RequestMapping("/seasons")
public class SeasonController {

    private final SeasonRepository seasonRepository;

    public SeasonController(SeasonRepository seasonRepository) {
        this.seasonRepository = seasonRepository;
    }


    @GetMapping("/")
    public String seasonsList(Model model) {
        model.addAttribute("seasons", seasonRepository.findAll());
        return "seasons/seasonsList";
    }


    @Scheduled(cron = "0 0 0 1 8 ?") //happens at the beginning of August, when transfer window starts
    public void addSeason() {
        Season newSeason = new Season();
        newSeason.setStartYear(LocalDate.now().getYear());
        newSeason.setEndYear(LocalDate.now().getYear() + 1);

        seasonRepository.save(newSeason);
        }


}


//    @GetMapping("/add")
//    public String addSeason() {
//        int currentMonth = LocalDate.now().getMonthValue();
//
//        Season newSeason = new Season();
//        newSeason.setStartYear(LocalDate.now().getYear());
//        newSeason.setEndYear(LocalDate.now().getYear() + 1);
//
//        List<Season> seasons = seasonRepository.findAll();
//
//        boolean seasonExists = seasons.stream()
//                .anyMatch(s -> s.getStartYear().equals(newSeason.getStartYear()));
//
//        if(currentMonth>=8 && !seasonExists){
//            seasonRepository.save(newSeason);
//        }
//
//        return "redirect:../seasons/";
//    }



