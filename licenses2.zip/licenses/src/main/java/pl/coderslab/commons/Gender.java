package pl.coderslab.commons;

public enum Gender {
    MALE, FEMALE
}
