package pl.coderslab.commons;

public enum AgeCategory {

    U12, U14, U16, U18, U20, senior

}
