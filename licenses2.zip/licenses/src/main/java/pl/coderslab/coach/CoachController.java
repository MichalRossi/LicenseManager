package pl.coderslab.coach;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import pl.coderslab.clubHistory.ClubHistory;
import pl.coderslab.clubHistory.ClubHistoryRepository;
import pl.coderslab.commons.AgeCategory;
import pl.coderslab.commons.Gender;
import pl.coderslab.club.Club;
import pl.coderslab.club.ClubRepository;
import pl.coderslab.season.Season;
import pl.coderslab.season.SeasonRepository;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@RequestMapping("/coaches")
public class CoachController {

    private final CoachRepository coachRepository;
    private final ClubRepository clubRepository;
    private final ClubHistoryRepository clubHistoryRepository;
    private final SeasonRepository seasonRepository;

    public CoachController(CoachRepository coachRepository, ClubRepository clubRepository, SeasonRepository seasonRepository,ClubHistoryRepository clubHistoryRepository) {
        this.coachRepository = coachRepository;
        this.clubRepository = clubRepository;
        this.seasonRepository = seasonRepository;
        this.clubHistoryRepository = clubHistoryRepository;
    }

    @GetMapping("/")
    public String coachList(Model model) {
        model.addAttribute("coaches", coachRepository.findAll());
        return "coach/coachesList";
    }


    @GetMapping("/add")
    public String addCoach(Model model) {
        model.addAttribute("coach", new Coach());
        return "coach/addCoach";
    }

    @PostMapping("/add")
    public String addCoach(Model model, @ModelAttribute @Valid Coach coach, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "coach/addCoach";
        }

        if (LocalDate.now().getMonthValue()!=8) {
            model.addAttribute("errorMessage", "Changes can be made only during transfer window.");
            return "club/addClub";
        }

        if(!coach.isValid()){
            coach.setValid(true);
        }

        ClubHistory coachHistory = new ClubHistory();
        Season currentSeason = seasonRepository.findLast();

        List<Season> firstStartSeason = new ArrayList<>();
        List<Season> firstEndSeason = new ArrayList<>();
        firstStartSeason.add(currentSeason);
        firstEndSeason.add(null);
        coachHistory.setStartSeasons(firstStartSeason);
        coachHistory.setEndSeason(firstEndSeason);

        List<Club> firstClub = new ArrayList<>();
        firstClub.add(coach.getClub());
        coachHistory.setClubs(firstClub);

        coach.setClubHistory(coachHistory);
        coachRepository.save(coach);
        return "redirect:../coaches/";
    }

    @GetMapping("/update/{id}")
    public String update(@PathVariable Long id, Model model) {
        Optional<Coach> coach = coachRepository.findById(id);
        model.addAttribute("coach", coach);
        return "coach/addCoach";
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable Long id, Model model, @ModelAttribute @Valid Coach coach, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "coach/addCoach";
        }

        if (LocalDate.now().getMonthValue()!=8) {
            model.addAttribute("errorMessage", "Changes can be made only during transfer window.");
            return "club/addClub";
        }

        Coach oldCoach = coachRepository.findCoachById(id);

        if(!oldCoach.getClub().equals(coach.getClub()) && coach.isValid()){
            ClubHistory coachHistory = coach.getClubHistory();
            Season currentSeason = seasonRepository.findLast();
            Club oldClub = oldCoach.getClub();

            List<Season> coachStartSeasons = coachHistory.getStartSeasons();
            List<Season> coachEndSeasons = coachHistory.getEndSeason();
            coachStartSeasons.add(currentSeason);
            coachEndSeasons.set(0,currentSeason);
            coachEndSeasons.add(null);
            coachHistory.setStartSeasons(coachStartSeasons);
            coachHistory.setEndSeason(coachEndSeasons);

            List<Club> coachClubHistory = coachHistory.getClubs();
            coachClubHistory.add(oldClub);
            coachHistory.setClubs(coachClubHistory);

            coach.setClubHistory(coachHistory);
        }

        if(!coach.isValid()){
            ClubHistory coachHistory = coach.getClubHistory();
            Season currentSeason = seasonRepository.findLast();

            List<Season> coachEndSeasons = coachHistory.getEndSeason();
            coachEndSeasons.set(0, currentSeason);
            coachHistory.setEndSeason(coachEndSeasons);

            coach.setClubHistory(coachHistory);
        }


        coachRepository.save(coach);
        return "redirect:../";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        coachRepository.deleteById(id);
        return "redirect:../";
    }

    @ModelAttribute("ageCategories")
    public List<AgeCategory> ageCategories() {
        return Stream.of(AgeCategory.values())
                .collect(Collectors.toList());
    }

    @ModelAttribute("genders")
    public List<Gender> genders() {
        return Stream.of(Gender.values())
                .collect(Collectors.toList());
    }

    @ModelAttribute("clubs")
    public List<Club> clubs() {
        return clubRepository.findAll();
    }

    @GetMapping("/club/{id}")
    public String clubCoaches(@PathVariable Long id, Model model) {

        List<Coach> clubCoaches = coachRepository.findCoachByClub(id);

        model.addAttribute("coaches",clubCoaches);
        return "coach/coachesList";
    }

    @GetMapping("/season/{id}")
    public String seasonCoaches(@PathVariable Long id, Model model) {

        List<Coach> coaches = coachRepository.findAll();
        Season season = seasonRepository.findById(id).orElse(null);

        List<Coach> seasonCoaches = coaches.stream()
                .filter(c -> c.getClubHistory()
                        .getStartSeasons()
                        .stream()
                            .allMatch(s -> s.getStartYear() <= season.getStartYear()))
                .filter(c -> c.getClubHistory()
                        .getEndSeason().stream()
                        .allMatch(s -> s==null || s.getStartYear() >= season.getStartYear()))
                .collect(Collectors.toList());

        model.addAttribute("coaches",seasonCoaches);
        return "coach/coachesList";
    }



}
